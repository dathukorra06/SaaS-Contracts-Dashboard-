import React, { useMemo, useState } from 'react'
import Sidebar from '../components/Sidebar'
import Topbar from '../components/Topbar'
import ContractsTable from '../components/ContractsTable'
import UploadModal from '../components/UploadModal'
import { useContracts } from '../context/ContractsContext'

export default function Dashboard() {
  const { contracts, loading, error } = useContracts()
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [riskFilter, setRiskFilter] = useState('')
  const [showUpload, setShowUpload] = useState(false)

  const filtered = useMemo(() => {
    return contracts.filter(c => {
      const q = query.trim().toLowerCase()
      if (q && !(c.name.toLowerCase().includes(q) || c.parties.toLowerCase().includes(q))) return false
      if (statusFilter && c.status !== statusFilter) return false
      if (riskFilter && c.risk !== riskFilter) return false
      return true
    })
  }, [contracts, query, statusFilter, riskFilter])

  return (
    <div className="min-h-screen flex bg-gray-100">
      <Sidebar />
      <div className="flex-1">
        <Topbar onUploadClick={() => setShowUpload(true)} />
        <main className="p-6">
          <div className="mb-4 flex gap-3">
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by name or parties" className="p-2 border rounded w-1/3" />
            <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="p-2 border rounded">
              <option value="">All Status</option>
              <option>Active</option>
              <option>Expired</option>
              <option>Renewal Due</option>
            </select>
            <select value={riskFilter} onChange={e=>setRiskFilter(e.target.value)} className="p-2 border rounded">
              <option value="">All Risk</option>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>
          </div>

          {loading && <div>Loading contracts...</div>}
          {error && <div className="text-red-600">Error: {error}</div>}
          {!loading && !error && filtered.length === 0 && <div>No contracts yet</div>}
          {!loading && !error && filtered.length > 0 && (
            <ContractsTable data={filtered} />
          )}
        </main>
      </div>

      {showUpload && <UploadModal onClose={() => setShowUpload(false)} />}
    </div>
  )
}
