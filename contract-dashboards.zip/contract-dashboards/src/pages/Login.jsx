import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState(null)
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = (e) => {
    e.preventDefault()
    const r = login({ username, password })
    if (r.ok) nav('/dashboard')
    else setErr(r.message)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form className="w-full max-w-md bg-white p-8 rounded shadow" onSubmit={submit}>
        <h2 className="text-xl font-semibold mb-4">Sign in</h2>
        {err && <div className="text-red-600 mb-2">{err}</div>}
        <label className="block mb-2">
          <span className="text-sm">Username</span>
          <input value={username} onChange={e=>setUsername(e.target.value)} className="mt-1 block w-full border rounded p-2" />
        </label>
        <label className="block mb-4">
          <span className="text-sm">Password</span>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="mt-1 block w-full border rounded p-2" />
        </label>
        <button className="w-full bg-blue-600 text-white py-2 rounded">Login</button>
        <p className="mt-2 text-xs text-gray-500">Use any username and password <strong>test123</strong></p>
      </form>
    </div>
  )
}
