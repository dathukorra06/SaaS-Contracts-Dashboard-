import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Sidebar from '../components/Sidebar'
import Topbar from '../components/Topbar'
import { getContractById } from '../api/contractApi'
import ClauseCard from '../components/ClauseCard'

export default function ContractDetail() {
  const { id } = useParams()
  const nav = useNavigate()
  const [contract, setContract] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showEvidence, setShowEvidence] = useState(false)

  useEffect(() => {
    setLoading(true)
    getContractById(id)
      .then(data => setContract(data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false))
  }, [id])

  if (loading) return <div className="min-h-screen flex"><Sidebar /><div className="p-6">Loading...</div></div>
  if (error) return <div className="min-h-screen flex"><Sidebar /><div className="p-6 text-red-600">Error: {error}</div></div>

  return (
    <div className="min-h-screen flex bg-gray-100">
      <Sidebar />
      <div className="flex-1">
        <Topbar />
        <main className="p-6">
          <button className="mb-4 text-sm text-blue-600" onClick={()=>nav('/dashboard')}>← Back to dashboard</button>
          <h1 className="text-2xl font-semibold">{contract.name}</h1>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded shadow">
              <p><strong>Parties:</strong> {contract.parties}</p>
              <p><strong>Start:</strong> {contract.start}</p>
              <p><strong>Expiry:</strong> {contract.expiry}</p>
              <p><strong>Status:</strong> {contract.status}</p>
              <p><strong>Risk:</strong> {contract.risk}</p>
            </div>
            <div className="bg-white p-4 rounded shadow">
              <h3 className="font-medium">AI Insights</h3>
              <ul className="mt-2 space-y-2">
                {contract.insights.map((ins, idx) => (
                  <li key={idx} className="p-2 border rounded">
                    <span className="text-sm font-semibold">{ins.risk}</span>
                    <p className="text-sm">{ins.message}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <section className="mt-6">
            <h2 className="text-lg font-semibold">Clauses</h2>
            <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
              {contract.clauses.map((c, i) => <ClauseCard key={i} clause={c} />)}
            </div>
          </section>

          <section className="mt-6">
            <h2 className="text-lg font-semibold">Evidence</h2>
            <button className="mt-2 px-3 py-2 bg-gray-200 rounded" onClick={()=>setShowEvidence(!showEvidence)}>{showEvidence ? 'Hide' : 'Show'} evidence</button>
            {showEvidence && (
              <div className="mt-3 bg-white p-4 rounded shadow">
                {contract.evidence.map((e, idx) => (
                  <div key={idx} className="mb-3">
                    <div className="text-sm text-gray-600">{e.source} — relevance {Math.round(e.relevance * 100)}%</div>
                    <div className="mt-1">{e.snippet}</div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </main>
      </div>
    </div>
  )
}
