import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import ContractDetail from './pages/ContractDetail'
import { useAuth } from './context/AuthContext'

export default function App() {
  const { token } = useAuth()
  return (
    <Routes>
      <Route path="/" element={token ? <Navigate to='/dashboard' /> : <Login />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={token ? <Dashboard /> : <Navigate to='/login' />} />
      <Route path="/contracts/:id" element={token ? <ContractDetail /> : <Navigate to='/login' />} />
      <Route path="*" element={<div className="p-8">404 - Not Found</div>} />
    </Routes>
  )
}
