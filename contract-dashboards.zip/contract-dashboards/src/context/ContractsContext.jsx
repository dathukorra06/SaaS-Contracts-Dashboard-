import React, { createContext, useContext, useEffect, useState } from 'react'

const ContractsContext = createContext()

export const ContractsProvider = ({ children }) => {
  const [contracts, setContracts] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const fetchContracts = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/contracts.json')
      if (!res.ok) throw new Error('Failed to load contracts')
      const data = await res.json()
      setContracts(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchContracts()
  }, [])

  return (
    <ContractsContext.Provider value={{ contracts, loading, error, refetch: fetchContracts }}>
      {children}
    </ContractsContext.Provider>
  )
}

export const useContracts = () => useContext(ContractsContext)
