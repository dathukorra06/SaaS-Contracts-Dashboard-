import React, { createContext, useContext, useEffect, useState } from 'react'

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem('mock_jwt') || null)
  const [user, setUser] = useState(localStorage.getItem('mock_user') || null)

  useEffect(() => {
    if (token) localStorage.setItem('mock_jwt', token)
    else localStorage.removeItem('mock_jwt')
  }, [token])

  useEffect(() => {
    if (user) localStorage.setItem('mock_user', user)
    else localStorage.removeItem('mock_user')
  }, [user])

  const login = ({ username, password }) => {
    if (password === 'test123') {
      const mock = 'mock-jwt-' + username
      setToken(mock)
      setUser(username)
      return { ok: true }
    }
    return { ok: false, message: 'Invalid credentials' }
  }

  const logout = () => {
    setToken(null)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
