export async function getContracts() {
  const res = await fetch('/contracts.json')
  if (!res.ok) throw new Error('Failed to fetch contracts')
  return res.json()
}

export async function getContractById(id) {
  // try fetching dedicated file first, fallback to list
  const res = await fetch(`/contract_${id}.json`)
  if (res.ok) return res.json()
  const list = await getContracts()
  const found = list.find(item => item.id === id)
  if (!found) throw new Error('Contract not found')
  return found
}
