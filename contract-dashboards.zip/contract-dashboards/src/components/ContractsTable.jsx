import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function ContractsTable({ data }) {
  const nav = useNavigate()
  const [page, setPage] = useState(1)
  const per = 10
  const total = Math.ceil(data.length / per)
  const pageData = data.slice((page-1)*per, page*per)

  return (
    <div className="bg-white rounded shadow overflow-x-auto">
      <table className="min-w-full">
        <thead>
          <tr className="text-left">
            <th className="p-3">Contract Name</th>
            <th className="p-3">Parties</th>
            <th className="p-3">Expiry Date</th>
            <th className="p-3">Status</th>
            <th className="p-3">Risk Score</th>
          </tr>
        </thead>
        <tbody>
          {pageData.map(row => (
            <tr key={row.id} className="border-t hover:bg-gray-50 cursor-pointer" onClick={()=>nav('/contracts/'+row.id)}>
              <td className="p-3">{row.name}</td>
              <td className="p-3">{row.parties}</td>
              <td className="p-3">{row.expiry}</td>
              <td className="p-3">{row.status}</td>
              <td className="p-3">{row.risk}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="p-3 flex items-center justify-between">
        <div>Showing {pageData.length} of {data.length}</div>
        <div className="space-x-2">
          <button disabled={page===1} onClick={()=>setPage(p=>p-1)} className="px-2 py-1 border rounded">Prev</button>
          <button disabled={page===total} onClick={()=>setPage(p=>p+1)} className="px-2 py-1 border rounded">Next</button>
        </div>
      </div>
    </div>
  )
}
