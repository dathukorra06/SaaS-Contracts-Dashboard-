import React, { useState } from 'react'

function simulateUpload(file, onProgress) {
  return new Promise((resolve, reject) => {
    let progress = 0
    const id = setInterval(() => {
      progress += Math.random() * 30
      if (progress >= 100) {
        clearInterval(id)
        // small chance to error
        if (Math.random() < 0.08) reject(new Error('Upload failed'))
        else resolve({ status: 'success' })
      } else onProgress(Math.min(100, Math.round(progress)))
    }, 300)
  })
}

export default function UploadModal({ onClose }) {
  const [files, setFiles] = useState([])

  const onFiles = async (e) => {
    const list = Array.from(e.target.files || e)
    const newFiles = list.map(f => ({ name: f.name, status: 'uploading', progress: 0 }))
    setFiles(prev => [...prev, ...newFiles])

    // simulate uploads sequentially
    for (let i = 0; i < list.length; i++) {
      const f = list[i]
      const idx = files.length + i
      try {
        await simulateUpload(f, (p) => {
          setFiles(prev => {
            const copy = [...prev]
            copy[idx] = { ...copy[idx], progress: p }
            return copy
          })
        })
        setFiles(prev => {
          const copy = [...prev]
          copy[idx] = { ...copy[idx], progress: 100, status: 'success' }
          return copy
        })
      } catch (err) {
        setFiles(prev => {
          const copy = [...prev]
          copy[idx] = { ...copy[idx], status: 'error' }
          return copy
        })
      }
    }
  }

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-11/12 max-w-lg">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg">Upload files</h3>
          <button onClick={onClose} className="text-sm">Close</button>
        </div>

        <input type="file" multiple onChange={onFiles} />

        <div className="mt-4 space-y-2">
          {files.map((f, i) => (
            <div key={i} className="p-2 border rounded">
              <div className="flex justify-between">
                <div>{f.name}</div>
                <div>{f.status} {f.progress ? `(${f.progress}%)` : ''}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
