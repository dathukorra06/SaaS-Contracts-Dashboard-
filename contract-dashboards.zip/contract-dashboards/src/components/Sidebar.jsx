import React from 'react'
export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r p-4 hidden md:block">
      <h2 className="text-xl font-semibold mb-4">Contracts</h2>
      <nav className="space-y-2">
        <a className="block p-2 rounded hover:bg-gray-100">Contracts</a>
        <a className="block p-2 rounded hover:bg-gray-100">Insights</a>
        <a className="block p-2 rounded hover:bg-gray-100">Reports</a>
        <a className="block p-2 rounded hover:bg-gray-100">Settings</a>
      </nav>
    </aside>
  )
}
