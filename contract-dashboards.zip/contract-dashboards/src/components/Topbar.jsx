import React from 'react'
import { useAuth } from '../context/AuthContext'

export default function Topbar({ onUploadClick }) {
  const { user, logout } = useAuth()
  return (
    <header className="flex items-center justify-between bg-white p-4 border-b">
      <div className="text-lg font-semibold">SaaS Contracts Dashboard</div>
      <div className="flex items-center gap-3">
        <button onClick={onUploadClick} className="px-3 py-1 border rounded">Upload</button>
        <div className="flex items-center gap-2">
          <span className="text-sm">{user}</span>
          <button onClick={logout} className="text-sm text-red-600">Logout</button>
        </div>
      </div>
    </header>
  )
}
