import React from 'react'

export default function ClauseCard({ clause }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex items-center justify-between">
        <h4 className="font-semibold">{clause.title}</h4>
        <div className="text-sm">{Math.round(clause.confidence * 100)}%</div>
      </div>
      <p className="mt-2 text-sm">{clause.summary}</p>
    </div>
  )
}
